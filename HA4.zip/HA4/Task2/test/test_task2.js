const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("GradeContract", function () {
  let professor, student1, student2;
  let gradeContract;

  beforeEach(async function () {
    [professor, student1, student2] = await ethers.getSigners();
    const GradeContract = await ethers.getContractFactory("GradeContract");
    gradeContract = await GradeContract.deploy();
    await gradeContract.deployed();
  });

  it("test case 1: first round (sum % 6 >= 3) + finalexam=0, inter>=6", async function () {
    const gradesStudent1 = [8, 7, 9, 8, 9, 10, 8, 0];

    await gradeContract.assignGrades(student1.address, gradesStudent1);
    await gradeContract.computeFinalGrade(student1.address);
    let finalGradeStudent1 = await gradeContract.finalGrades(student1.address);

    expect(finalGradeStudent1).to.equal(9);
  });

  it("test case 2: first round (sum % 6 < 3) + finalexam=0, inter>=6", async function () {
    const gradesStudent1 = [8, 7, 9, 8, 7, 10, 8, 0];

    await gradeContract.assignGrades(student1.address, gradesStudent1);
    await gradeContract.computeFinalGrade(student1.address);
    let finalGradeStudent1 = await gradeContract.finalGrades(student1.address);

    expect(finalGradeStudent1).to.equal(8);
  });

  it("test case 3: finalexam=0, inter<6", async function () {
    const gradesStudent1 = [4, 4, 4, 4, 4, 4, 4, 0];

    await gradeContract.assignGrades(student1.address, gradesStudent1);
    await gradeContract.computeFinalGrade(student1.address);
    let finalGradeStudent1 = await gradeContract.finalGrades(student1.address);

    expect(finalGradeStudent1).to.equal(0);
  });

  it("test case 4: finalexam>0 + second round (sum % 10 >=5)", async function () {
    const gradesStudent1 = [8, 7, 9, 8, 9, 10, 8, 10];

    await gradeContract.assignGrades(student1.address, gradesStudent1);
    await gradeContract.computeFinalGrade(student1.address);
    let finalGradeStudent1 = await gradeContract.finalGrades(student1.address);

    expect(finalGradeStudent1).to.equal(10);
  });

  it("test case 5: finalexam>0 + second round (sum % 10 < 5)", async function () {
    const gradesStudent1 = [8, 7, 9, 8, 9, 10, 8, 8];

    await gradeContract.assignGrades(student1.address, gradesStudent1);
    await gradeContract.computeFinalGrade(student1.address);
    let finalGradeStudent1 = await gradeContract.finalGrades(student1.address);

    expect(finalGradeStudent1).to.equal(8);
  });

  it("test case 6: min inter (finalexam=0, first roundGrade > 10)", async function () {
    const gradesStudent1 = [15, 10, 10, 16, 10, 10, 8, 10];

    await gradeContract.assignGrades(student1.address, gradesStudent1);
    await gradeContract.computeFinalGrade(student1.address);
    let finalGradeStudent1 = await gradeContract.finalGrades(student1.address);

    expect(finalGradeStudent1).to.equal(10);
  });

  it("test case 7: min final (finalexam>0, second roundGrade > 10)", async function () {
    // imagine if student can get bonus on exam
    // without this second min not needed, because interGrade after first min <=10 and finalExam <=10
    const gradesStudent1 = [15, 10, 10, 16, 10, 10, 8, 15];

    await gradeContract.assignGrades(student1.address, gradesStudent1);
    await gradeContract.computeFinalGrade(student1.address);
    let finalGradeStudent1 = await gradeContract.finalGrades(student1.address);

    expect(finalGradeStudent1).to.equal(10);
  });


});
