const { expect } = require("chai");

const MyTestToken = artifacts.require("MyTestToken");

contract("MyTestToken", accounts => {
  let myTestTokenInstance;
  const sender = accounts[0];
  const receiver1 = accounts[1];
  const receiver2 = accounts[2];
  const tokensAmountToTransfer = 5;

  beforeEach(async () => {
    myTestTokenInstance = await MyTestToken.new();
  });

  it("should transfer tokens to Receiver_1", async () => {
    const startSenderBalance = await myTestTokenInstance.balanceOf(sender);
    const startReceiver1Balance = await myTestTokenInstance.balanceOf(receiver1);

    const transaction = await myTestTokenInstance.transfer(receiver1, tokensAmountToTransfer, { from: sender });

    const finalSenderBalance = await myTestTokenInstance.balanceOf(sender);
    const finalReceiver1Balance = await myTestTokenInstance.balanceOf(receiver1);

    assert.equal(finalSenderBalance.toString(), (startSenderBalance - tokensAmountToTransfer).toString());
    assert.equal(finalReceiver1Balance.toString(), (startReceiver1Balance + tokensAmountToTransfer).toString());

    console.log('Transaction Successful:', transaction.status);
    assert.equal(transaction.status, true);

    console.log('Gas Consumption:', transaction.gasUsed);

  });

  it("should transfer tokens to Receiver_2", async () => {
    const startSenderBalance = await myTestTokenInstance.balanceOf(sender);
    const startReceiver2Balance = await myTestTokenInstance.balanceOf(receiver2);

    const transaction = await myTestTokenInstance.transfer(receiver2, tokensAmountToTransfer, { from: sender });

    const finalSenderBalance = await myTestTokenInstance.balanceOf(sender);
    const finalReceiver2Balance = await myTestTokenInstance.balanceOf(receiver2);

    assert.equal(finalSenderBalance.toString(), (startSenderBalance - tokensAmountToTransfer).toString());
    assert.equal(finalReceiver2Balance.toString(), (startReceiver2Balance + tokensAmountToTransfer).toString());

    console.log('Transaction Successful:', transaction.status);
    assert.equal(transaction.status, true);

    console.log('Gas Consumption:', transaction.gasUsed);

  });
});
